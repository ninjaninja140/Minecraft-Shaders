## Translators
   Translators are listed from first to last. Please keep the list format in order. You may link your name to your Github profile.
* [@Eldeston](https://github.com/Eldeston) (English)
* [@Felix14_v2](https://github.com/Felix14-v2) (Russian)
* [@ItIsNotAPlayer](https://github.com/ItIsNotAPlayer) (Simplified Chinese)
